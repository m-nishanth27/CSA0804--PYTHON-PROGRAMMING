"""Task 10 - float vs Decimal, rounding strategy, dictionary rate table."""
import random, time, sys, timeit
from decimal import Decimal as D, ROUND_HALF_UP

random.seed(2026)
PAISE = D("0.01")
BASE, FV, SV = D("30.00"), D("0.40"), D("0.30")

def make_entries(n):
    """litres with 2 decimals, fat/snf with 1 decimal (clerk entries) as strings."""
    return [(f"{random.uniform(1, 40):.2f}", f"{random.uniform(2.5, 6.5):.1f}",
             f"{random.uniform(7.5, 9.5):.1f}") for _ in range(n)]

def rate_dec(fat, snf):
    fs = ((D(fat) - D("3.5")) / D("0.1")).quantize(D("1"), rounding=ROUND_HALF_UP)
    ss = ((D(snf) - D("8.5")) / D("0.1")).quantize(D("1"), rounding=ROUND_HALF_UP)
    return BASE + fs * FV + ss * SV

def pay_float(l, f, s):
    rate = 30.0 + round((float(f) - 3.5) / 0.1) * 0.40 + round((float(s) - 8.5) / 0.1) * 0.30
    return float(l) * rate

print("=== Experiment A/B: float vs Decimal totals and time ===")
print(f"{'n':>8} {'float total':>22} {'Decimal total':>16} {'abs diff':>14} {'t_float(s)':>11} {'t_dec(s)':>9}")
for n in (300, 6000, 150000):
    data = make_entries(n)
    t0 = time.perf_counter()
    tf = 0.0
    for l, f, s in data:
        tf += pay_float(l, f, s)
    t_f = time.perf_counter() - t0
    t0 = time.perf_counter()
    td = D(0)
    for l, f, s in data:
        td += D(l) * rate_dec(f, s)
    t_d = time.perf_counter() - t0
    print(f"{n:>8} {tf:>22.10f} {str(td):>16} {abs(D(tf) - td):>14.2E} {t_f:>11.4f} {t_d:>9.4f}")

print("\n=== Experiment C: round each payment vs round only the final total ===")
print(f"{'n':>8} {'round each':>14} {'round final':>14} {'difference':>12}")
for n in (300, 6000, 150000):
    data = make_entries(n)
    exact = [D(l) * rate_dec(f, s) for l, f, s in data]
    each = sum(p.quantize(PAISE, rounding=ROUND_HALF_UP) for p in exact)
    final = sum(exact).quantize(PAISE, rounding=ROUND_HALF_UP)
    print(f"{n:>8} {str(each):>14} {str(final):>14} {str(each - final):>12}")
print("Each farmer is paid a whole-paise amount, so the money actually leaving the bank")
print("is the sum of the per-payment rounded values ('round each').")

print("\n=== Additional: dictionary rate table vs recalculation ===")
data = make_entries(150000)
pairs = {(f, s) for _, f, s in data}
print("distinct (fat, snf) pairs k =", len(pairs))
t0 = time.perf_counter()
table = {p: rate_dec(*p) for p in pairs}
t_build = time.perf_counter() - t0
t0 = time.perf_counter()
tot1 = sum(D(l) * rate_dec(f, s) for l, f, s in data)
t_recalc = time.perf_counter() - t0
t0 = time.perf_counter()
tot2 = sum(D(l) * table[(f, s)] for l, f, s in data)
t_lookup = time.perf_counter() - t0
print(f"recalculate every entry : {t_recalc:.4f} s  total={tot1}")
print(f"dictionary lookup       : {t_lookup:.4f} s  total={tot2}  (+ {t_build:.4f} s to build table)")
print("totals identical:", tot1 == tot2, "| speed-up x%.2f" % (t_recalc / t_lookup))
print("table size (dict object only):", sys.getsizeof(table), "bytes for k =", len(table))
fat, snf = "4.2", "8.7"
tim_r = timeit.timeit(lambda: rate_dec(fat, snf), number=100000) / 100000
tim_l = timeit.timeit(lambda: table.get((fat, snf)), number=100000) / 100000
print(f"timeit per call: recalculation {tim_r*1e6:.2f} us | lookup {tim_l*1e6:.3f} us")
