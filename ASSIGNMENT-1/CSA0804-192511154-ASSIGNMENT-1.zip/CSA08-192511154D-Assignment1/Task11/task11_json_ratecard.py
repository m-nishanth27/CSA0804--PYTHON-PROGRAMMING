"""Task 11 - Load the rate card from JSON instead of hard-coding it."""
import json, time, sys
from decimal import Decimal as D, ROUND_HALF_UP
from pathlib import Path

REQUIRED = {"base_rate", "fat_step_value", "snf_step_value", "std_fat", "std_snf",
            "min_fat", "max_fat", "effective_from"}

def load_rate_card(path):
    """Load + validate; fail loudly at start-up rather than pay wrongly later."""
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    missing = REQUIRED - raw.keys()
    if missing:
        raise KeyError(f"rate card missing keys: {sorted(missing)}")
    card = {k: (D(v) if k != "effective_from" else v) for k, v in raw.items()}
    if card["base_rate"] <= 0:
        raise ValueError("base_rate must be positive")
    return card

def rate_per_litre(card, fat, snf):
    step = D("0.1")
    fs = ((D(fat) - card["std_fat"]) / step).quantize(D("1"), rounding=ROUND_HALF_UP)
    ss = ((D(snf) - card["std_snf"]) / step).quantize(D("1"), rounding=ROUND_HALF_UP)
    return (card["base_rate"] + fs * card["fat_step_value"]
            + ss * card["snf_step_value"]).quantize(D("0.01"))

here = Path(__file__).with_name("rates.json")
t0 = time.perf_counter()
card = load_rate_card(here)
load_time = time.perf_counter() - t0
print("loaded rate card:", {k: str(v) for k, v in card.items()})
print(f"load time (t = {len(card)} values): {load_time*1e6:.1f} microseconds")
print("space of dict object:", sys.getsizeof(card), "bytes")
print("rate 4.2/8.7 ->", rate_per_litre(card, "4.2", "8.7"))

# Safe rate revision demo: change the file, no code edit
revised = dict(json.loads(here.read_text()), base_rate="32.00", fat_step_value="0.45",
               effective_from="2026-04-01")
tmp = here.with_name("rates_apr_jun.json"); tmp.write_text(json.dumps(revised, indent=2))
card2 = load_rate_card(tmp)
print("revised card 4.2/8.7 ->", rate_per_litre(card2, "4.2", "8.7"), "(no code change, only data)")
try:
    load_rate_card(here.with_name("missing.json"))
except FileNotFoundError as exc:
    print("missing file is detected at start-up:", type(exc).__name__)
