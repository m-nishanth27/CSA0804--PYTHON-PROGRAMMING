"""Task 06 - Functions, scope, return vs print, lambda."""
import time

BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STD_FAT, STD_SNF, STEP = 3.5, 8.5, 0.1


def rate_per_litre(fat, snf):
    """Return the rate (Rs/litre) for the given fat and SNF percentage."""
    fat_steps = round((fat - STD_FAT) / STEP)
    snf_steps = round((snf - STD_SNF) / STEP)
    return round(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE, 2)


def payout(litres, fat, snf):
    """Return the payment for one delivery (litres x rate, 2 decimals)."""
    return round(litres * rate_per_litre(fat, snf), 2)


def ten_day_total(entries):
    """Return the total payment over a ten-day cycle.

    entries: iterable of (litres, fat, snf) tuples (up to 20 shifts).
    """
    total = 0.0
    for litres, fat, snf in entries:
        total += payout(litres, fat, snf)
    return round(total, 2)


def show_payout(litres, fat, snf):      # prints, returns None - cannot be reused
    print("payment:", payout(litres, fat, snf))

# lambda version
payout_lambda = lambda l, f, s: round(l * (BASE_RATE + round((f - STD_FAT) / STEP) * FAT_STEP_VALUE
                                           + round((s - STD_SNF) / STEP) * SNF_STEP_VALUE), 2)

if __name__ == "__main__":
    week = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)] * 6 + [(10, 3.5, 8.5)] * 2
    print("rate_per_litre(4.2, 8.7) =", rate_per_litre(4.2, 8.7))
    print("payout(8.5, 4.2, 8.7)    =", payout(8.5, 4.2, 8.7))
    print("ten_day_total (20 shifts) =", ten_day_total(week))

    r = show_payout(10, 3.5, 8.5)
    print("show_payout returned:", r, "(print != return)")
    print("payout * 2 =", payout(10, 3.5, 8.5) * 2, "(returned value is reusable)")

    # Scope demo
    counter = 0                               # global
    def bad_update():
        counter = 99                          # creates a LOCAL variable
        return counter
    bad_update()
    print("global counter after bad_update():", counter, "(unchanged)")
    print("Rate constants are read inside functions (no 'global' needed);")
    print("assigning to BASE_RATE inside a function would create a local, not change the global.")

    # overhead
    data = week * 5000
    t0 = time.perf_counter(); a = ten_day_total(data); t1 = time.perf_counter()
    b = round(sum(payout_lambda(*e) for e in data), 2); t2 = time.perf_counter()
    print(f"n={len(data)}: functions {t1 - t0:.4f}s total={a} | lambda {t2 - t1:.4f}s total={b}")
