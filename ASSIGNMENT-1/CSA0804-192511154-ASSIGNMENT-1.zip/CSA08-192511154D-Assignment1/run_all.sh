#!/usr/bin/env bash
set -e
for f in Task01/task01_analysis.py Task02/task02_types.py Task03/task03_constants.py \
         Task04/task04_expressions.py Task05/task05_input.py Task06/task06_functions.py \
         Task10/task10_experiments.py Task11/task11_json_ratecard.py; do
  echo "################ $f"; python3 "$f"
done
(cd Task07 && echo "################ Task07" && python3 milkrate.py && python3 use_milkrate.py)
(cd Task08 && echo "################ Task08" && python3 task08_trace.py && python3 task08_flowchart.py)
(cd Task09 && echo "################ Task09" && python3 test_calculator.py)
(cd Task12 && echo "################ Task12" && python3 task12_tests.py)
