"""Task 04 - Expressions, steps, rounding behaviour, precedence."""
import math

BASE_RATE, STD_FAT, STD_SNF = 30.00, 3.5, 8.5
FAT_STEP_VALUE, SNF_STEP_VALUE = 0.40, 0.30

fat, snf, litres = 4.2, 8.7, 8.5
fat_steps = round((fat - STD_FAT) / 0.1)
snf_steps = round((snf - STD_SNF) / 0.1)
rate = BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE
payment = round(litres * rate, 2)
print(f"fat_steps={fat_steps} snf_steps={snf_steps} rate={rate:.2f} payment={payment:.2f}")

print("\n--- precedence / associativity ---")
print("-2 ** 2    =", -2 ** 2, "  (** binds tighter than unary minus)")
print("(-2) ** 2  =", (-2) ** 2)
print("2 ** 3 ** 2 =", 2 ** 3 ** 2, " (** is right-associative)")
print("10 - 4 - 3 =", 10 - 4 - 3, "  (- is left-associative)")
print("2 + 3 * 4  =", 2 + 3 * 4)

print("\n--- unexpected float results (>= 3) ---")
print("(4.2 - 3.5) / 0.1       =", (4.2 - 3.5) / 0.1)
print("int((4.2 - 3.5) / 0.1)  =", int((4.2 - 3.5) / 0.1), "(happens to be right: 7.000000000000002 truncates to 7)")
print("(4.3 - 3.5) / 0.1       =", (4.3 - 3.5) / 0.1)
print("int((4.3 - 3.5) / 0.1)  =", int((4.3 - 3.5) / 0.1), "<- WRONG (should be 8)")
print("(3.1 - 3.5) / 0.1       =", (3.1 - 3.5) / 0.1)
print("int((3.1 - 3.5) / 0.1)  =", int((3.1 - 3.5) / 0.1), "<- WRONG (should be -4)")
print("round((4.3 - 3.5) / 0.1)  =", round((4.3 - 3.5) / 0.1), "<- round() always recovers the true step count")
print("0.1 + 0.2 == 0.3        =", 0.1 + 0.2 == 0.3)
print("round(2.675, 2)         =", round(2.675, 2), "<- not 2.68")
print("round(0.5), round(1.5), round(2.5) =", round(0.5), round(1.5), round(2.5), "(banker's rounding)")

print("\n--- round vs int vs floor on negative values ---")
for v in (-3.9, -3.5, -3.1, -0.5):
    print(f"{v:5}: round={round(v):3}  int={int(v):3}  floor={math.floor(v):3}")

print("\n--- Additional question: fat 4.2 and 3.1 ---")
for f in (4.2, 3.1):
    raw = (f - STD_FAT) / 0.1
    for name, fn in (("round", round), ("int", int), ("floor", math.floor)):
        s = fn(raw)
        r = BASE_RATE + s * FAT_STEP_VALUE
        print(f"fat {f}: raw={raw!r:22} {name:5} steps={s:3} fat-only rate={r:.2f}")

print("\n--- comparison chaining ---")
for f in (1.9, 2.0, 4.2, 7.0, 7.1):
    print(f, "valid:", 2.0 <= f <= 7.0, "| same as:", (2.0 <= f) and (f <= 7.0))
