# CSA08-192511154D-Assignment1

**Name:** M Nishanth
**Register number:** 192511154D
**Course:** Python Programming - CO1 Assignment 1 (SIMATS)
**Topic:** Payment calculator for the Ksheera Village Milk Producers' Co-operative

## Environment
- Python 3.12 (works on 3.9+)
- Libraries: standard library only (`decimal`, `time`, `timeit`, `json`, `math`, `sys`, `random`, `pathlib`, `tracemalloc`)
  plus `matplotlib` (Task 08 flowchart image only)

## How to run (from the repository root)
```bash
python Task01/task01_analysis.py
python Task02/task02_types.py
python Task03/task03_constants.py
python Task04/task04_expressions.py
python Task05/task05_input.py
python Task06/task06_functions.py
cd Task07 && python milkrate.py && python use_milkrate.py && cd ..
cd Task08 && python task08_trace.py && python task08_flowchart.py && cd ..
cd Task09 && python test_calculator.py && cd ..      # interactive: python milk_calculator.py
python Task10/task10_experiments.py
python Task11/task11_json_ratecard.py
cd Task12 && python task12_tests.py && cd ..
```
Or run everything: `bash run_all.sh`

## Task summary
| Task | Content |
|---|---|
| 01 | Inputs, outputs, constants, data types, validation rules, separate variables vs list of tuples |
| 02 | Types, `/ // %`, `0.1+0.2`, TODO 1 (`total_decimal`), Decimal vs paise vs float |
| 03 | Named constants, dynamic typing, swap, magic numbers vs constants vs `RATE_CARD` dict |
| 04 | Fat/SNF steps, precedence, `round` vs `int` vs `floor`, comparison chaining |
| 05 | `input()` conversion, `try/except ValueError`, f-string formatting, string methods vs try/except |
| 06 | `rate_per_litre`, `payout`, `ten_day_total`, scope, return vs print, lambda |
| 07 | `milkrate.py` module (TODO 1 and 2), importing script, `__main__` guard |
| 08 | Pseudocode, flowchart (`flowchart.png`), hand-trace, list vs running total |
| 09 | Complete Decimal-based calculator + 14 automated assert tests |
| 10 | float vs Decimal for 300/6,000/150,000 payments, rounding strategy, rate-table timing |
| 11 | JSON rate card loader, safe rate revision, final recommendation |
| 12 | Seasonal rates, two-decimal analyser readings, bonus - `milkrate_v2.py` + 21 tests |

The full written answers are in the assignment report (`Assignment1_Report.docx` / `.pdf`).
