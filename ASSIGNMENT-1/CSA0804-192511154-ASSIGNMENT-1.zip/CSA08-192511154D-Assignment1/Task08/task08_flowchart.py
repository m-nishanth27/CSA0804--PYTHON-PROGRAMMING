"""Draw the flowchart for validating and calculating one entry -> flowchart.png"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

fig, ax = plt.subplots(figsize=(9, 12))
ax.set_xlim(0, 10); ax.set_ylim(0, 15); ax.axis("off")

def box(x, y, text, w=3.6, h=0.9, color="#dfeaf7"):
    ax.add_patch(FancyBboxPatch((x - w/2, y - h/2), w, h, boxstyle="round,pad=0.05",
                                fc=color, ec="#1f3a5f", lw=1.5))
    ax.text(x, y, text, ha="center", va="center", fontsize=9)

def diamond(x, y, text, w=3.8, h=1.3):
    ax.add_patch(Polygon([(x, y+h/2), (x+w/2, y), (x, y-h/2), (x-w/2, y)],
                         fc="#fff2cc", ec="#7f6000", lw=1.5))
    ax.text(x, y, text, ha="center", va="center", fontsize=8.5)

def arrow(x1, y1, x2, y2, label=None):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="->", lw=1.4, color="#333"))
    if label:
        ax.text((x1+x2)/2 + 0.15, (y1+y2)/2 + 0.1, label, fontsize=9, color="#a00")

X = 4
box(X, 14.3, "START", w=2, color="#d9ead3")
box(X, 13.1, "Read litres, fat, snf", )
diamond(X, 11.5, "litres >= 0 ?")
diamond(X, 9.5, "2.0 <= fat <= 7.0 ?")
diamond(X, 7.5, "6.0 <= snf <= 12.0 ?")
box(X, 5.6, "fat_steps = round((fat-3.5)/0.1)\nsnf_steps = round((snf-8.5)/0.1)", w=4.6, h=1.1)
box(X, 4.1, "rate = 30 + fat_steps*0.40 + snf_steps*0.30", w=4.8)
box(X, 2.9, "payment = round(litres * rate, 2)")
box(X, 1.7, "Print payment", w=2.6)
box(X, 0.6, "END", w=2, color="#d9ead3")
box(8.2, 9.5, "Print error message\n(reject entry)", w=3.0, color="#f4cccc")
box(8.6, 0.6, "END", w=1.6, color="#d9ead3")

arrow(X, 13.85, X, 13.55); arrow(X, 12.65, X, 12.15)
arrow(X, 10.85, X, 10.15, "Yes"); arrow(X, 8.85, X, 8.15, "Yes"); arrow(X, 6.85, X, 6.15, "Yes")
arrow(X, 5.05, X, 4.55); arrow(X, 3.65, X, 3.35); arrow(X, 2.45, X, 2.15); arrow(X, 1.25, X, 1.05)
# litres < 0  -> error box (top)
ax.plot([X+1.9, 8.2], [11.5, 11.5], color="#333", lw=1.4)
arrow(8.2, 11.5, 8.2, 9.95); ax.text(6.3, 11.62, "No", fontsize=9, color="#a00")
# fat out of range -> error box (left side)
arrow(X+1.9, 9.5, 6.7, 9.5); ax.text(6.0, 9.62, "No", fontsize=9, color="#a00")
# snf out of range -> error box (bottom, left lane)
ax.plot([X+1.9, 7.4], [7.5, 7.5], color="#333", lw=1.4)
arrow(7.4, 7.5, 7.4, 9.05); ax.text(6.0, 7.62, "No", fontsize=9, color="#a00")
# error box -> END (right lane)
arrow(8.9, 9.05, 8.9, 1.05)
ax.set_title("Flowchart - validate and calculate one milk entry", fontsize=12)
plt.savefig("flowchart.png", dpi=130, bbox_inches="tight")
print("saved flowchart.png")
