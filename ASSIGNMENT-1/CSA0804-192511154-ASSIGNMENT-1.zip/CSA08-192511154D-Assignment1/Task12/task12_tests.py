"""Task 12 - worked examples, comparison with original design, and tests."""
import sys
from decimal import Decimal as D
from milkrate_v2 import *

print("=== A/B. Impact of two-decimal readings on step calculation ===")
print(f"{'fat':>6} {'raw steps':>10} {'float round()':>15} {'half-up (v2)':>13} {'proportional':>13}")
for fat in ("4.20", "4.23", "4.25", "4.15", "4.26", "3.46"):
    raw = (D(fat) - STD_FAT) / STEP
    py = round(float(fat) / 1 * 10 - 35)              # naive float route
    print(f"{fat:>6} {str(raw):>10} {py:>15} {str(steps(D(fat), STD_FAT)):>13} {str(raw):>13}")
print("-> 4.15 and 4.25 sit exactly half-way: float/banker's rounding is unpredictable;")
print("   Decimal + ROUND_HALF_UP gives one documented rule.")

print("\n=== Original design vs new requirements (fat 4.23, snf 8.67, 10 L) ===")
old_rate = 30.00 + round((4.23 - 3.5) / 0.1) * 0.40 + round((8.67 - 8.5) / 0.1) * 0.30
print("original code (float, regular card):", round(old_rate, 2), "-> cannot express season or bonus")
print("v2 regular rate :", rate_per_litre("4.23", "8.67", "regular"))
print("v2 Apr-Jun rate :", rate_per_litre("4.23", "8.67", "apr_to_jun"))

print("\n=== D. Tests ===")
rows = []
def check(desc, got, expected):
    status = "PASS" if got == D(expected) else "FAIL"
    rows.append((desc, str(got), expected, status))
    assert status == "PASS", (desc, got, expected)

check("regular rate 4.2/8.7",          rate_per_litre("4.20", "8.70", "regular"), "33.40")
check("Apr-Jun rate 4.2/8.7",          rate_per_litre("4.20", "8.70", "apr_to_jun"), "35.75")
check("Apr-Jun standard milk 3.5/8.5", rate_per_litre("3.50", "8.50", "apr_to_jun"), "32.00")
check("regular payout 8.5L 4.2/8.7",   payout("8.5", "4.20", "8.70", "regular"), "283.90")
check("Apr-Jun payout 8.5L 4.2/8.7",   payout("8.5", "4.20", "8.70", "apr_to_jun"), "303.88")
check("two-decimal fat 4.23 -> 7 steps",rate_per_litre("4.23", "8.50", "regular"), "32.80")
check("half-way fat 4.25 -> 8 steps",  rate_per_litre("4.25", "8.50", "regular"), "33.20")
check("bonus exactly 500 L -> 0",      bonus("500"), "0.00")
check("bonus 500.01 L",                bonus("500.01"), "250.01")
check("bonus 600 L",                   bonus("600"), "300.00")

# ten-day cycles: 20 shifts x 20 L = 400 L (no bonus); 20 x 30 L = 600 L (bonus)
no_bonus = [("20", "3.50", "8.50")] * 20
with_bonus = [("30", "3.50", "8.50")] * 20
p, b, l, g = ten_day_total(no_bonus, "regular");     check("cycle 400 L regular: total", g, "12000.00"); check("cycle 400 L bonus", b, "0.00")
p, b, l, g = ten_day_total(with_bonus, "regular");   check("cycle 600 L regular: total", g, "18300.00"); check("cycle 600 L bonus", b, "300.00")
p, b, l, g = ten_day_total(with_bonus, "apr_to_jun");check("cycle 600 L Apr-Jun: total", g, "19500.00"); check("cycle 600 L Apr-Jun bonus", b, "300.00")
check("season for May", D(1) if season_for_month(5) == "apr_to_jun" else D(0), "1")
check("season for July", D(1) if season_for_month(7) == "regular" else D(0), "1")

for bad in (("-1", "3.5", "8.5"), ("10", "7.01", "8.5"), ("10", "eight", "8.5")):
    try:
        payout(*bad); raise SystemExit("should have been rejected")
    except InvalidEntry:
        rows.append((f"reject {bad}", "Rejected", "Rejected", "PASS"))

print(f"{'Test':38}{'Actual':>12}{'Expected':>12}  Result")
for r in rows:
    print(f"{r[0]:38}{r[1]:>12}{r[2]:>12}  {r[3]}")
print(f"\nALL {len(rows)} TESTS PASSED")
