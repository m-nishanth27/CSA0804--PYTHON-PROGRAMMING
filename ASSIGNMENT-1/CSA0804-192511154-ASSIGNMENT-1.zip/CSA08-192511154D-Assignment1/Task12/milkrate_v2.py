"""milkrate_v2.py - Task 12: seasonal rate cards, two-decimal analyser readings, bonus.

Decision: MODIFY (not redesign). Pure functions and Decimal arithmetic are kept;
constants move into a RATE_CARDS dictionary selected by season.
"""
from decimal import Decimal as D, ROUND_HALF_UP

PAISE = D("0.01")
STEP = D("0.1")
STD_FAT, STD_SNF = D("3.5"), D("8.5")
MIN_FAT, MAX_FAT = D("2.00"), D("7.00")
MIN_SNF, MAX_SNF = D("6.00"), D("12.00")

# One rate card per season - a rate revision = editing this dictionary only.
RATE_CARDS = {
    "regular":    {"base": D("30.00"), "fat_step": D("0.40"), "snf_step": D("0.30")},
    "apr_to_jun": {"base": D("32.00"), "fat_step": D("0.45"), "snf_step": D("0.30")},
}
BONUS_THRESHOLD_LITRES = D("500")     # strictly MORE than 500 litres in ten days
BONUS_PER_LITRE = D("0.50")           # assumption: paid on ALL litres of that cycle


class InvalidEntry(ValueError):
    pass


def season_for_month(month):
    """April(4)..June(6) -> 'apr_to_jun', otherwise 'regular'."""
    if not 1 <= month <= 12:
        raise InvalidEntry("month must be 1-12")
    return "apr_to_jun" if 4 <= month <= 6 else "regular"


def _dec(value, name):
    try:
        d = D(str(value).strip())
    except Exception:
        raise InvalidEntry(f"{name}: '{value}' is not a number")
    if not d.is_finite():
        raise InvalidEntry(f"{name}: '{value}' is not finite")
    return d


def steps(value, standard):
    """Nearest whole 0.1 step; ties (e.g. 4.25 -> 7.5 steps) round HALF UP, explicitly."""
    return ((value - standard) / STEP).quantize(D("1"), rounding=ROUND_HALF_UP)


def rate_per_litre(fat, snf, season="regular"):
    card = RATE_CARDS[season]
    fat, snf = _dec(fat, "fat"), _dec(snf, "snf")
    if not (MIN_FAT <= fat <= MAX_FAT):
        raise InvalidEntry(f"fat {fat} outside {MIN_FAT}-{MAX_FAT}")
    if not (MIN_SNF <= snf <= MAX_SNF):
        raise InvalidEntry(f"snf {snf} outside {MIN_SNF}-{MAX_SNF}")
    rate = card["base"] + steps(fat, STD_FAT) * card["fat_step"] + steps(snf, STD_SNF) * card["snf_step"]
    return rate.quantize(PAISE, rounding=ROUND_HALF_UP)


def payout(litres, fat, snf, season="regular"):
    litres = _dec(litres, "litres")
    if litres < 0:
        raise InvalidEntry("litres must be non-negative")
    return (litres * rate_per_litre(fat, snf, season)).quantize(PAISE, rounding=ROUND_HALF_UP)


def bonus(total_litres):
    """Bonus for ten-day litres: 0.50/litre on all litres if strictly > 500."""
    total_litres = _dec(total_litres, "total_litres")
    if total_litres > BONUS_THRESHOLD_LITRES:
        return (total_litres * BONUS_PER_LITRE).quantize(PAISE, rounding=ROUND_HALF_UP)
    return D("0.00")


def ten_day_total(entries, season="regular"):
    """entries: iterable of (litres, fat, snf). Returns (payments, bonus, total_litres, grand_total)."""
    pay = D("0.00"); litres_sum = D("0")
    for litres, fat, snf in entries:
        pay += payout(litres, fat, snf, season)
        litres_sum += _dec(litres, "litres")
    b = bonus(litres_sum)
    return pay, b, litres_sum, pay + b
