"""Task 03 - Named constants, dynamic typing, multiple assignment."""

BASE_RATE = 30.00
STD_FAT = 3.5
STD_SNF = 8.5
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
MIN_FAT, MAX_FAT = 2.0, 7.0
MIN_SNF, MAX_SNF = 6.0, 12.0

RATE_CARD = {"base": 30.0, "fat": 0.40, "snf": 0.30}

def rate_magic(fat, snf):            # magic numbers: change in many places
    return 30.0 + round((fat - 3.5) / 0.1) * 0.40 + round((snf - 8.5) / 0.1) * 0.30

def rate_const(fat, snf):            # named constants: change in ONE place
    return (BASE_RATE + round((fat - STD_FAT) / 0.1) * FAT_STEP_VALUE
            + round((snf - STD_SNF) / 0.1) * SNF_STEP_VALUE)

def rate_dict(fat, snf, card=RATE_CARD):   # dict: swap whole card at runtime
    return (card["base"] + round((fat - 3.5) / 0.1) * card["fat"]
            + round((snf - 8.5) / 0.1) * card["snf"])

print("magic :", round(rate_magic(4.2, 8.7), 2))
print("const :", round(rate_const(4.2, 8.7), 2))
print("dict  :", round(rate_dict(4.2, 8.7), 2))

BASE_RATE = 99.0
print("BASE_RATE silently changed to", BASE_RATE, "(no error) - only convention protects it")
BASE_RATE = 30.00

x = 10;    print("x =", x, type(x))
x = "ten"; print("x =", x, type(x))

litres, fat, snf = 10, 3.5, 8.5
print("litres, fat, snf =", litres, fat, snf)
a, b = 3.5, 8.5
print("before swap:", a, b)
a, b = b, a
print("after  swap:", a, b)
