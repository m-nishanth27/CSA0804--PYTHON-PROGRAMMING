"""Task 05 - Reading input and converting types."""

def parse_float_try(text):
    """try/except approach."""
    try:
        return float(text)
    except ValueError:
        return None

def parse_float_methods(text):
    """string-method approach (pre-validation)."""
    t = text.strip()
    if t.count(".") <= 1 and t.replace(".", "", 1).isdigit():
        return float(t)
    return None

print("input() always returns str:", type("8.5"))
print("int('10') =", int("10"), "| float('8.5') =", float("8.5"))

print("\n--- invalid inputs: try/except vs string methods ---")
print(f"{'text':12}{'try/except':>14}{'str methods':>14}")
for text in ["8,5", " 8.5 ", "eight", "8.5", "-3", "", "1e1"]:
    print(f"{text!r:12}{str(parse_float_try(text)):>14}{str(parse_float_methods(text)):>14}")

def read_float(prompt, lo=None, hi=None, source=None):
    """Read a float with validation. `source` lets tests feed values without keyboard."""
    while True:
        raw = next(source) if source is not None else input(prompt)
        try:
            value = float(raw)
        except ValueError:
            print(f"  Invalid number {raw!r}; use digits and '.' (e.g. 8.5)")
            continue
        if (lo is not None and value < lo) or (hi is not None and value > hi):
            print(f"  {value} out of range [{lo}, {hi}]")
            continue
        return value

if __name__ == "__main__":
    # scripted clerk entries so output is reproducible
    feed = iter(["eight", "8,5", "-2", "8.5"])
    litres = read_float("Litres: ", lo=0, source=feed)
    amount = litres * 33.40
    print("\nFormatted output with f-strings:")
    print(f"|{'Litres':>8}|{'Amount':>10}|")
    print(f"|{litres:8.1f}|{amount:10.2f}|")
    print(f"amount={amount:8.2f}  as percent-style fat={4.2:5.1f}%")
