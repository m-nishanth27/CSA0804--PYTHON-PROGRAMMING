"""Second script: imports milkrate and calls payout()."""
import milkrate
from milkrate import payout
import milkrate as mr
import sys, os

print("payout via 'from milkrate import payout':", payout(8.5, 4.2, 8.7))
print("rate   via 'import milkrate'            :", milkrate.rate_per_litre(3.1, 8.3))
print("payout via 'import milkrate as mr'      :", mr.payout(12, 3.1, 8.3))
print("milkrate cached in sys.modules:", "milkrate" in sys.modules)
print("module file:", os.path.basename(milkrate.__file__))
print("module __name__ when imported:", milkrate.__name__)
print("sys.path[0] is the folder of the running script:", os.path.basename(sys.path[0]))
