"""Task 09 - Automated test table using assert statements."""
from decimal import Decimal as D
from milk_calculator import payout, rate_per_litre, ten_day_total, InvalidEntry

tests = []   # (description, input, expected)

def ok(desc, args, expected):
    tests.append((desc, args, D(expected), "pay"))

def bad(desc, args):
    tests.append((desc, args, None, "err"))

ok("1 above standard",            (8.5, 4.2, 8.7), "283.90")
ok("2 below standard",            (12, 3.1, 8.3), "333.60")
ok("3 boundary 3.5 / 8.5",        (10, 3.5, 8.5), "300.00")
ok("4a lowest fat 2.0",           (10, 2.0, 8.5), "240.00")
ok("4b highest fat 7.0",          (10, 7.0, 8.5), "440.00")
ok("zero litres",                 (0, 3.5, 8.5), "0.00")
bad("5a text 'eight' litres",     ("eight", 3.5, 8.5))
bad("5b comma decimal '8,5'",     ("8,5", 3.5, 8.5))
bad("5c empty fat",               (10, "", 8.5))
bad("6 negative litres",          (-5, 3.5, 8.5))
bad("7a fat below 2.0",           (10, 1.9, 8.5))
bad("7b fat above 7.0",           (10, 7.1, 8.5))
ok("extra: string with spaces",   (" 8.5 ", " 4.2 ", " 8.7 "), "283.90")

passed = 0
print(f"{'Test':32}{'Input':26}{'Expected':>10}{'Actual':>28}  Result")
for desc, args, expected, kind in [t for t in tests if t]:
    try:
        actual = payout(*args); got = str(actual)
    except InvalidEntry as exc:
        actual = None; got = "Rejected"
    if kind == "pay":
        status = actual == expected
        exp = str(expected)
    else:
        status = actual is None
        exp = "Rejected"
    passed += status
    print(f"{desc:32}{str(args):26}{exp:>10}{got:>28}  {'PASS' if status else 'FAIL'}")
    assert status, desc

# 8. five-entry sample with manually calculated total
five = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3), (20, 3.8, 8.6), (5, 3.0, 8.0)]
manual = [D("300.00"), D("283.90"), D("333.60"), D("630.00"), D("132.50")]
for e, m in zip(five, manual):
    assert payout(*e) == m, (e, m)
total, errors = ten_day_total(five)
print("\nFive-entry set: manual total 1680.00 | program total", total, "| errors", errors)
assert total == D("1680.00") and not errors
passed += 1
print(f"\nALL {passed} CHECKS PASSED")
