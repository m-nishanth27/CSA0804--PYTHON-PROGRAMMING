"""Complete milk payment calculator (Task 09). Money is handled with Decimal."""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
STD_FAT = Decimal("3.5")
STD_SNF = Decimal("8.5")
STEP = Decimal("0.1")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
MIN_FAT, MAX_FAT = Decimal("2.0"), Decimal("7.0")
MIN_SNF, MAX_SNF = Decimal("6.0"), Decimal("12.0")
PAISE = Decimal("0.01")


class InvalidEntry(ValueError):
    """Raised when a clerk entry breaks a validation rule."""


def to_decimal(text, name):
    """Convert text/number to Decimal; reject '8,5', 'eight', '', NaN, Infinity."""
    try:
        value = Decimal(str(text).strip())
    except Exception:
        raise InvalidEntry(f"{name}: '{text}' is not a valid number")
    if not value.is_finite():
        raise InvalidEntry(f"{name}: '{text}' is not a finite number")
    return value


def steps_from(value, standard):
    """Whole 0.1 steps away from the standard (nearest step, half-up)."""
    return ((value - standard) / STEP).quantize(Decimal("1"), rounding=ROUND_HALF_UP)


def validate(litres, fat, snf):
    """Return validated Decimals or raise InvalidEntry."""
    litres, fat, snf = (to_decimal(litres, "litres"), to_decimal(fat, "fat"),
                        to_decimal(snf, "snf"))
    if litres < 0:
        raise InvalidEntry("litres must be non-negative")
    if not (MIN_FAT <= fat <= MAX_FAT):
        raise InvalidEntry(f"fat {fat} outside {MIN_FAT}-{MAX_FAT}")
    if not (MIN_SNF <= snf <= MAX_SNF):
        raise InvalidEntry(f"snf {snf} outside {MIN_SNF}-{MAX_SNF}")
    return litres, fat, snf


def rate_per_litre(fat, snf):
    fat, snf = to_decimal(fat, "fat"), to_decimal(snf, "snf")
    rate = (BASE_RATE + steps_from(fat, STD_FAT) * FAT_STEP_VALUE
            + steps_from(snf, STD_SNF) * SNF_STEP_VALUE)
    return rate.quantize(PAISE, rounding=ROUND_HALF_UP)


def payout(litres, fat, snf):
    litres, fat, snf = validate(litres, fat, snf)
    return (litres * rate_per_litre(fat, snf)).quantize(PAISE, rounding=ROUND_HALF_UP)


def ten_day_total(entries):
    """Sum of payouts. Returns (total, list_of_error_messages)."""
    total, errors = Decimal("0.00"), []
    for idx, (litres, fat, snf) in enumerate(entries, 1):
        try:
            total += payout(litres, fat, snf)
        except InvalidEntry as exc:
            errors.append(f"entry {idx}: {exc}")
    return total, errors


def main():
    print("Milk payment calculator (Ctrl+C to quit)")
    while True:
        try:
            litres = input("Litres: "); fat = input("Fat %: "); snf = input("SNF %: ")
            print(f"Rate {rate_per_litre(fat, snf)}  Payment Rs {payout(litres, fat, snf)}")
        except InvalidEntry as exc:
            print("Rejected:", exc)
        except (KeyboardInterrupt, EOFError):
            print(); break


if __name__ == "__main__":
    main()
