"""Task 01 - Problem analysis: data, constants, validation rules, scalability demo."""
import sys, time

INPUTS = {
    "farmer_id": "str  (e.g. 'F0001'; an ID, never used in arithmetic)",
    "litres":    "float (>= 0, may be fractional e.g. 8.5)",
    "fat":       "float (2.0 .. 7.0 %)",
    "snf":       "float (SNF %, assumed 6.0 .. 12.0)",
    "shift":     "str   ('M' morning / 'E' evening)",
}
OUTPUTS = {
    "rate_per_litre": "float (Rs per litre)",
    "payment":        "float (Rs, 2 decimals)",
    "ten_day_total":  "float (Rs, sum of up to 20 payments)",
    "is_valid":       "bool",
}
CONSTANTS = {
    "BASE_RATE": 30.00, "STD_FAT": 3.5, "STD_SNF": 8.5, "STEP": 0.1,
    "FAT_STEP_VALUE": 0.40, "SNF_STEP_VALUE": 0.30,
    "MIN_FAT": 2.0, "MAX_FAT": 7.0, "MIN_SNF": 6.0, "MAX_SNF": 12.0,
    "PAYMENT_CYCLE_DAYS": 10, "SHIFTS_PER_DAY": 2,
}
for title, d in (("INPUTS", INPUTS), ("OUTPUTS", OUTPUTS), ("CONSTANTS", CONSTANTS)):
    print(f"--- {title} ---")
    for k, v in d.items():
        print(f"{k:20} {v}")

print("\n--- Separate variables vs list of tuples (n = 300) ---")
entries = [(10 + i % 7, 3.0 + (i % 20) / 10, 8.0 + (i % 10) / 10) for i in range(300)]
t0 = time.perf_counter()
total_litres = sum(e[0] for e in entries)          # O(n) time, O(n) space
print("list-of-tuples total litres:", total_litres,
      "| time %.6f s" % (time.perf_counter() - t0))
print("Separate variables would need 900 names (litres1..litres300, fat1.., snf1..)")
print("and one hand-written line per farmer: code size O(n), cannot loop, cannot grow at runtime.")
print("Container size for 300 tuples:", sys.getsizeof(entries), "bytes (list object only)")
