"""Task 02 - Values and types, float precision, Decimal vs float vs paise."""
import sys, time
from decimal import Decimal

print("--- type() of values ---")
for v in (10, 10.0, "10", True, [10, 8.5]):
    print(f"{v!r:10} -> {type(v)}")

print("\n--- division operators ---")
print("-7 / 2  =", -7 / 2)
print("7 / 2   =", 7 / 2)
print("-7 % 2  =", -7 % 2, "  (result takes sign of divisor)")
print("-7 // 2 =", -7 // 2, " (floor division rounds toward -infinity)")
print("7 // 2  =", 7 // 2)

print("\n--- 0.1 + 0.2 == 0.3 ---")
print(0.1 + 0.2, 0.1 + 0.2 == 0.3)

payments = ["33.40"] * 1000 + ["0.10"] * 3

def total_float(items):
    total = 0.0
    for amount in items:
        total += float(amount)
    return total

def total_decimal(items):
    # TODO 1 completed: build a Decimal from each *string* and add exactly
    total = Decimal("0")
    for amount in items:
        total += Decimal(amount)
    return total

print("\n--- Completed program ---")
print("float  :", total_float(payments))
print("Decimal:", total_decimal(payments))
print(0.1 + 0.2 == 0.3, Decimal("0.1") + Decimal("0.2") == Decimal("0.3"))

def total_decimal_from_float(items):
    total = Decimal("0")
    for amount in items:
        total += Decimal(float(amount))
    return total
print("\nDecimal(float(amount)):", total_decimal_from_float(payments))
print("Decimal(float('33.40')) =", Decimal(float("33.40")))
print("-> the float 33.40 is already inexact; Decimal copies that error exactly.")

def total_paise(items):
    paise = 0
    for a in items:
        paise += int(Decimal(a) * 100)
    return paise / 100

def total_float_rounded(items):
    t = 0.0
    for a in items:
        t = round(t + float(a), 2)
    return t

print("\n--- Three approaches (1,003 payments x 100 repeats) ---")
for name, fn in (("Decimal", total_decimal), ("int paise", total_paise),
                 ("float+round", total_float_rounded)):
    t0 = time.perf_counter(); r = fn(payments * 100); dt = time.perf_counter() - t0
    print(f"{name:12} result={r} time={dt:.4f}s")
print("sys.getsizeof(float)   =", sys.getsizeof(1.5))
print("sys.getsizeof(int)     =", sys.getsizeof(3340))
print("sys.getsizeof(Decimal) =", sys.getsizeof(Decimal('33.40')))
